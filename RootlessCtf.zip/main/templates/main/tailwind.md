# Documentazione HTML + Tailwind CSS
> Riferimento pratico per lo sviluppo di RootlessCTF

---

## Indice
1. [Struttura HTML di base](#1-struttura-html-di-base)
2. [Tag HTML principali](#2-tag-html-principali)
3. [Layout con Tailwind](#3-layout-con-tailwind)
4. [Spaziatura](#4-spaziatura)
5. [Tipografia](#5-tipografia)
6. [Colori e sfondi](#6-colori-e-sfondi)
7. [Bordi e arrotondamenti](#7-bordi-e-arrotondamenti)
8. [Dimensioni](#8-dimensioni)
9. [Componenti comuni](#9-componenti-comuni)
10. [Interattività e stati](#10-interattività-e-stati)
11. [Template Django + Tailwind](#11-template-django--tailwind)

---

## 1. Struttura HTML di base

```html
<!DOCTYPE html>
<html lang="it" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Titolo pagina</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-zinc-950 text-zinc-300">

    <!-- contenuto -->

</body>
</html>
```

| Tag / Attributo | Scopo |
|---|---|
| `<!DOCTYPE html>` | Dichiara il documento come HTML5 |
| `lang="it"` | Lingua del documento (accessibilità, SEO) |
| `class="h-full"` | Necessario su `<html>` e `<body>` per layout a tutta altezza |
| `charset="UTF-8"` | Supporto caratteri speciali e accenti |
| `viewport` | Rende la pagina responsive su mobile |

---

## 2. Tag HTML principali

### Struttura e layout
| Tag | Uso |
|---|---|
| `<div>` | Contenitore generico a blocco |
| `<span>` | Contenitore generico inline |
| `<main>` | Contenuto principale della pagina |
| `<aside>` | Contenuto laterale (sidebar) |
| `<nav>` | Barre di navigazione |
| `<header>` | Intestazione sezione o pagina |
| `<footer>` | Piè di pagina |
| `<section>` | Sezione tematica di contenuto |

### Testo
| Tag | Uso |
|---|---|
| `<h1>` … `<h6>` | Titoli, dal più importante al meno |
| `<p>` | Paragrafo |
| `<strong>` | Testo in grassetto (importanza semantica) |
| `<em>` | Testo in corsivo (enfasi semantica) |
| `<code>` | Codice inline |
| `<pre>` | Blocco di codice preformattato |
| `<br>` | Interruzione di riga |

### Form
| Tag | Uso |
|---|---|
| `<form>` | Contenitore del form |
| `<input>` | Campo di input (testo, password, file, hidden…) |
| `<label>` | Etichetta collegata a un input |
| `<button>` | Pulsante |
| `<select>` | Menu a tendina |
| `<option>` | Voce del menu a tendina |
| `<textarea>` | Campo di testo multiriga |

### Media e link
| Tag | Uso |
|---|---|
| `<a href="...">` | Link |
| `<img src="..." alt="...">` | Immagine |
| `<video>` | Video |

---

## 3. Layout con Tailwind

### Flexbox
Flexbox dispone gli elementi in riga o colonna.

```html
<div class="flex">            <!-- riga orizzontale -->
<div class="flex flex-col">   <!-- colonna verticale -->
```

| Classe | Effetto |
|---|---|
| `flex` | Attiva flexbox |
| `flex-col` | Direzione verticale |
| `flex-row` | Direzione orizzontale (default) |
| `items-center` | Allinea verticalmente al centro |
| `items-start` | Allinea in alto |
| `items-end` | Allinea in basso |
| `justify-center` | Centra orizzontalmente |
| `justify-between` | Spazio tra gli elementi |
| `justify-end` | Allinea a destra |
| `gap-4` | Spazio tra gli elementi (1rem) |
| `flex-1` | L'elemento occupa tutto lo spazio disponibile |
| `shrink-0` | L'elemento non si restringe |
| `flex-wrap` | Va a capo se non c'è spazio |

**Esempio — card con immagine e testo affiancati:**
```html
<div class="flex items-center gap-4">
    <img src="..." class="w-12 h-12 rounded-full shrink-0">
    <div class="flex-1">
        <p class="font-bold">Username</p>
        <p class="text-sm text-zinc-500">email@esempio.com</p>
    </div>
</div>
```

---

### Grid
Grid dispone gli elementi in una griglia a colonne.

```html
<div class="grid grid-cols-3 gap-4">
    <div>...</div>
    <div>...</div>
    <div>...</div>
</div>
```

| Classe | Effetto |
|---|---|
| `grid` | Attiva grid |
| `grid-cols-1` | 1 colonna |
| `grid-cols-2` | 2 colonne |
| `grid-cols-3` | 3 colonne |
| `grid-cols-4` | 4 colonne |
| `gap-4` | Spazio tra celle (1rem) |
| `col-span-2` | L'elemento occupa 2 colonne |

**Esempio — griglia responsive:**
```html
<!-- 1 colonna su mobile, 2 su tablet, 3 su desktop -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
```

---

### Posizionamento
| Classe | Effetto |
|---|---|
| `relative` | Posizionamento relativo (punto di riferimento per i figli) |
| `absolute` | Posizionamento assoluto rispetto al genitore `relative` |
| `fixed` | Fisso rispetto alla viewport (es. sidebar fissa) |
| `sticky` | Si comporta come `relative` finché non raggiunge il bordo, poi diventa `fixed` |
| `top-0` | Distanza dal bordo superiore: 0 |
| `left-0` | Distanza dal bordo sinistro: 0 |
| `z-10` | Z-index: 10 (sovrappone elementi) |
| `inset-0` | top/right/bottom/left tutti a 0 (riempie il genitore) |

---

## 4. Spaziatura

### Padding (spazio interno)
| Classe | Effetto |
|---|---|
| `p-4` | Padding su tutti i lati (1rem = 16px) |
| `px-4` | Padding orizzontale (sinistra + destra) |
| `py-4` | Padding verticale (sopra + sotto) |
| `pt-4` | Padding solo sopra |
| `pb-4` | Padding solo sotto |
| `pl-4` | Padding solo a sinistra |
| `pr-4` | Padding solo a destra |

### Margin (spazio esterno)
| Classe | Effetto |
|---|---|
| `m-4` | Margin su tutti i lati |
| `mx-auto` | Centra orizzontalmente un elemento a larghezza fissa |
| `mt-4` | Margin solo sopra |
| `mb-4` | Margin solo sotto |
| `-mt-4` | Margin negativo (sposta l'elemento verso l'alto) |

### Scala valori
| Valore | px equivalenti |
|---|---|
| `1` | 4px |
| `2` | 8px |
| `3` | 12px |
| `4` | 16px |
| `5` | 20px |
| `6` | 24px |
| `8` | 32px |
| `10` | 40px |
| `12` | 48px |
| `16` | 64px |

---

## 5. Tipografia

| Classe | Effetto |
|---|---|
| `text-xs` | Font size 12px |
| `text-sm` | Font size 14px |
| `text-base` | Font size 16px (default) |
| `text-lg` | Font size 18px |
| `text-xl` | Font size 20px |
| `text-2xl` | Font size 24px |
| `text-3xl` | Font size 30px |
| `font-normal` | Peso normale (400) |
| `font-medium` | Peso medio (500) |
| `font-bold` | Grassetto (700) |
| `tracking-tight` | Letterspacing ridotto |
| `tracking-wide` | Letterspacing aumentato |
| `tracking-widest` | Letterspacing massimo |
| `leading-relaxed` | Interlinea rilassata |
| `truncate` | Taglia il testo con `…` se troppo lungo |
| `uppercase` | Tutto maiuscolo |
| `capitalize` | Prima lettera maiuscola |
| `text-center` | Testo centrato |
| `text-right` | Testo allineato a destra |

---

## 6. Colori e sfondi

Tailwind usa scale di colori da `50` (chiaro) a `950` (scuro).

### Colori testo
```html
<p class="text-white">         <!-- bianco -->
<p class="text-zinc-300">      <!-- grigio chiaro -->
<p class="text-zinc-500">      <!-- grigio medio -->
<p class="text-zinc-600">      <!-- grigio scuro -->
<p class="text-green-400">     <!-- verde -->
<p class="text-yellow-400">    <!-- giallo -->
<p class="text-red-400">       <!-- rosso -->
<p class="text-blue-400">      <!-- blu -->
```

### Colori sfondo
```html
<div class="bg-zinc-950">   <!-- quasi nero -->
<div class="bg-zinc-900">   <!-- nero card -->
<div class="bg-zinc-800">   <!-- grigio scuro -->
<div class="bg-white">      <!-- bianco -->
```

### Opacità colore
Aggiungendo `/30`, `/50` ecc. si controlla l'opacità del colore:
```html
<div class="bg-green-900/30">   <!-- verde scuro al 30% opacità -->
<div class="bg-red-900/40">     <!-- rosso scuro al 40% opacità -->
```

### Colori custom (definiti nel config)
```html
<!-- Definito in tailwind.config con 'brand': '#00ff9d' -->
<span class="text-brand">      <!-- verde brand -->
<div class="bg-brand">         <!-- sfondo verde brand -->
```

---

## 7. Bordi e arrotondamenti

### Bordi
| Classe | Effetto |
|---|---|
| `border` | Bordo 1px |
| `border-2` | Bordo 2px |
| `border-zinc-700` | Colore bordo grigio scuro |
| `border-zinc-800` | Colore bordo quasi nero |
| `border-t` | Solo bordo superiore |
| `border-b` | Solo bordo inferiore |
| `border-l` | Solo bordo sinistro |
| `border-r` | Solo bordo destro |

### Arrotondamenti
| Classe | Effetto |
|---|---|
| `rounded` | Arrotondamento piccolo (4px) |
| `rounded-md` | Arrotondamento medio (6px) |
| `rounded-lg` | Arrotondamento grande (8px) |
| `rounded-xl` | Arrotondamento extra (12px) |
| `rounded-full` | Completamente tondo (pill o cerchio) |

---

## 8. Dimensioni

### Larghezza
| Classe | Effetto |
|---|---|
| `w-full` | 100% della larghezza del genitore |
| `w-screen` | 100% della larghezza della viewport |
| `w-auto` | Larghezza automatica |
| `w-px` | 1px |
| `w-4` | 1rem (16px) |
| `w-16` | 4rem (64px) |
| `w-56` | 14rem (224px) — usato per la sidebar |
| `max-w-sm` | Larghezza massima 384px |
| `max-w-md` | Larghezza massima 448px |
| `max-w-2xl` | Larghezza massima 672px |
| `max-w-5xl` | Larghezza massima 1024px |

### Altezza
| Classe | Effetto |
|---|---|
| `h-full` | 100% dell'altezza del genitore |
| `h-screen` | 100% dell'altezza della viewport |
| `h-px` | 1px |
| `h-2` | 8px — usato per barre progress |
| `h-16` | 64px |
| `min-h-screen` | Altezza minima pari alla viewport |
| `max-h-64` | Altezza massima 256px |
| `overflow-hidden` | Nasconde il contenuto che eccede |
| `overflow-y-auto` | Scroll verticale se il contenuto eccede |

---

## 9. Componenti comuni

### Bottone primario
```html
<button class="px-4 py-2 rounded bg-white text-zinc-950 font-bold text-sm hover:bg-zinc-200 transition-colors">
    Clicca
</button>
```

### Bottone outline
```html
<button class="px-4 py-2 rounded border border-zinc-700 text-zinc-400 text-sm hover:border-zinc-500 hover:text-white transition-colors">
    Clicca
</button>
```

### Input testo
```html
<input type="text" placeholder="Scrivi qui..."
       class="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-sm text-zinc-300 outline-none focus:border-zinc-500 transition-colors">
```

### Card
```html
<div class="bg-zinc-900 border border-zinc-800 rounded-lg p-4 hover:border-zinc-600 transition-colors">
    <!-- contenuto -->
</div>
```

### Badge
```html
<!-- Verde -->
<span class="text-xs px-2 py-0.5 rounded-full bg-green-900/30 text-green-400 border border-green-800">
    Completata
</span>

<!-- Giallo -->
<span class="text-xs px-2 py-0.5 rounded-full bg-yellow-900/30 text-yellow-400 border border-yellow-800">
    Medio
</span>

<!-- Rosso -->
<span class="text-xs px-2 py-0.5 rounded-full bg-red-900/30 text-red-400 border border-red-800">
    Difficile
</span>
```

### Avatar circolare
```html
<!-- Con immagine -->
<img src="foto.jpg" class="w-16 h-16 rounded-full object-cover border-2 border-zinc-700">

<!-- Fallback con iniziale -->
<div class="w-16 h-16 rounded-full bg-zinc-800 border-2 border-zinc-700 flex items-center justify-center text-xl font-bold text-zinc-400">
    A
</div>
```

### Messaggio di errore / successo
```html
<!-- Errore -->
<div class="px-4 py-3 rounded border border-red-800 bg-red-900/30 text-red-400 text-sm">
    Messaggio di errore
</div>

<!-- Successo -->
<div class="px-4 py-3 rounded border border-green-800 bg-green-900/30 text-green-400 text-sm">
    Operazione riuscita
</div>
```

### Barra di progressi
```html
<div class="relative w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
    <!-- Riempimento dinamico -->
    <div class="h-full bg-white rounded-full transition-all duration-500"
         style="width: 65%;"></div>
    <!-- Separatore -->
    <div class="absolute top-0 h-full w-px bg-zinc-600" style="left: 33%;"></div>
</div>
```

---

## 10. Interattività e stati

### Hover
Aggiungendo il prefisso `hover:` la classe si applica solo al passaggio del mouse:
```html
<button class="bg-zinc-800 hover:bg-zinc-700">...</button>
<a class="text-zinc-400 hover:text-white">...</a>
```

### Focus
Si applica quando l'elemento è selezionato (es. input):
```html
<input class="border-zinc-700 focus:border-zinc-500">
```

### Transizioni
```html
<div class="transition-colors">       <!-- solo colori -->
<div class="transition-all">          <!-- tutto -->
<div class="transition-all duration-300">  <!-- con durata 300ms -->
```

### Responsive (breakpoints)
Aggiungendo un prefisso si applica la classe solo da una certa larghezza in su:
| Prefisso | Larghezza minima |
|---|---|
| _(nessuno)_ | Tutti i dispositivi |
| `sm:` | 640px+ |
| `md:` | 768px+ |
| `lg:` | 1024px+ |
| `xl:` | 1280px+ |

```html
<!-- 1 colonna su mobile, 3 su desktop -->
<div class="grid grid-cols-1 lg:grid-cols-3">
```

---

## 11. Template Django + Tailwind

### Ereditarietà template
```django
{# Template figlio #}
{% extends 'main/base.html' %}

{% block title %}Titolo pagina{% endblock %}

{% block content %}
    <!-- contenuto specifico della pagina -->
{% endblock %}
```

### Blocchi definiti in base.html di RootlessCTF
| Blocco | Dove usarlo |
|---|---|
| `{% block title %}` | Titolo del tab del browser |
| `{% block content %}` | Contenuto pagine post-login (con sidebar) |
| `{% block public_content %}` | Contenuto pagine pubbliche (home, login, registrazione) |
| `{% block nav_dashboard %}` | Aggiungere classe `active` al link Dashboard |
| `{% block nav_catalogo %}` | Aggiungere classe `active` al link Catalogo |
| `{% block nav_profilo %}` | Aggiungere classe `active` al link Profilo |
| `{% block nav_password %}` | Aggiungere classe `active` al link Cambia Password |
| `{% block extra_css %}` | Aggiungere CSS aggiuntivo nella pagina |
| `{% block extra_js %}` | Aggiungere JS aggiuntivo nella pagina |

### Esempio voce sidebar attiva
```django
{% block nav_catalogo %}text-white bg-zinc-800{% endblock %}
```

### Variabili e filtri utili
```django
{{ utente.username }}              {# Stampa il valore #}
{{ utente.username|first|upper }}  {# Prima lettera maiuscola #}
{{ testo|capfirst }}               {# Prima lettera maiuscola #}
{{ numero|add:5 }}                 {# Somma #}
{{ lista|join:", " }}              {# Unisce lista con separatore #}

{% if condizione %}...{% endif %}
{% for item in lista %}...{% endfor %}
{% empty %}                        {# Dentro il for, se la lista è vuota #}
{% url 'nome_url' %}               {# Genera URL da nome #}
{% static 'path/file.css' %}       {# URL file statico #}
{% csrf_token %}                   {# Token sicurezza nei form POST #}
```

### Form Django con Tailwind
```django
{# Renderizza tutti i campi in loop con stile uniforme #}
{% for field in form %}
<div>
    <label for="{{ field.id_for_label }}" class="block text-xs text-zinc-400 mb-1">
        {{ field.label }}
    </label>
    {{ field }}
    {% if field.errors %}
    <p class="text-red-400 text-xs mt-1">{{ field.errors|join:", " }}</p>
    {% endif %}
</div>
{% endfor %}
```

> **Nota:** i widget Django generano HTML senza classi Tailwind.
> Per stilarli usa CSS tradizionale nel blocco `{% block extra_css %}` o in un tag `<style>` puntando ai selettori `input[type="text"]`, `input[type="file"]` ecc.

---

*Documentazione aggiornata al 17/03/2026 — RootlessCTF*