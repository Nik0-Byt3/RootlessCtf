from django.contrib import admin
from django.urls import path , include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('main.urls')),
    path('sqli/', include('sqli.urls')),
    path('cookie/', include('cookie.urls')),
    path('visitor/' , include('visitor.urls')),
    path('ssrf/', include('ssrf.urls')),
    path('cryptography/' , include('cryptography.urls')),
    path('forencics/' , include('forencics.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
